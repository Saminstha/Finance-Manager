import type {
  ErrorRequestHandler,
  NextFunction,
  Request,
  Response,
} from "express";
import { ZodError } from "zod";

export const errorHandler: ErrorRequestHandler = (
  error: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction,
) => {
  console.error(error);

  if (error instanceof ZodError) {
    res.status(400).json({
      message: "Validation failed",
      errors: error.issues,
    });
    return;
  }

  if (error instanceof Error) {
    if (
      error.message === "Missing or invalid Authorization header" ||
      error.message === "Invalid access token"
    ) {
      res.status(401).json({
        message: "Unauthorized",
      });
      return;
    }
  }

  res.status(500).json({
    message: "Server error",
  });
};
