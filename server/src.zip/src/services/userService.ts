import bcrypt from "bcryptjs";
import { User } from "../models/User";
import { Account } from "../models/Account";
import { Transaction } from "../models/Transaction";
import { Budget } from "../models/Budget";
import { Saving } from "../models/Saving";

export async function getUserById(userId: string) {
  const user = await User.findById(userId).select("-password");

  if (!user) {
    throw new Error("User not found");
  }

  return user;
}

export async function updateUser(
  userId: string,
  data: {
    name?: string;
    phone?: string;
    dateOfBirth?: Date;
  },
) {
  const user = await User.findByIdAndUpdate(
    userId,
    { $set: data },
    {
      new: true,
      runValidators: true,
    },
  ).select("-password");

  if (!user) {
    throw new Error("User not found");
  }

  return user;
}

export async function changePassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
) {
  const user = await User.findById(userId).select("+password");

  if (!user) {
    throw new Error("User not found");
  }

  const passwordMatch = await bcrypt.compare(currentPassword, user.password);

  if (!passwordMatch) {
    throw new Error("Current password is incorrect");
  }

  user.password = await bcrypt.hash(newPassword, 10);

  await user.save();
}

export async function deleteUser(userId: string) {
  const user = await User.findById(userId);

  if (!user) {
    throw new Error("User not found");
  }

  await Transaction.deleteMany({
    userId,
  });

  await Budget.deleteMany({
    userId,
  });

  await Saving.deleteMany({
    userId,
  });

  await Account.deleteMany({
    userId,
  });

  await user.deleteOne();
}
