import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error("JWT_SECRET is not defined in the environment variables");
}

const ACCESS_TOKEN_EXPIRES_IN = "15m";

export interface AccessTokenPayload {
  id: string;
  type: "access";
}

export function signAccessToken(userId: string): string {
  return jwt.sign(
    {
      id: userId,
      type: "access",
    },
    JWT_SECRET as string,
    {
      expiresIn: ACCESS_TOKEN_EXPIRES_IN,
    },
  );
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  const payload = jwt.verify(token, JWT_SECRET as string);

  if (
    typeof payload !== "object" ||
    payload === null ||
    typeof payload.id !== "string" ||
    payload.type !== "access"
  ) {
    throw new Error("Invalid access token");
  }

  return {
    id: payload.id,
    type: "access",
  };
}
