import { Router } from "express";
import {
  deleteMe,
  getMe,
  updateMe,
  updatePassword,
} from "../controllers/userController";
import { authenticate } from "../auth/authenticate";

const router = Router();

router.use(authenticate);

router.get("/me", getMe);
router.patch("/me", updateMe);
router.patch("/me/password", updatePassword);
router.delete("/me", deleteMe);

export default router;
