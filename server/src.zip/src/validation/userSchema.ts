import { z } from "zod";

export const createUserSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3, "Username must be at least 3 characters")
    .regex(
      /^[A-Za-z0-9_]+$/,
      "Username can only contain letters, numbers and underscore",
    ),

  name: z.string().trim().min(1, "Name is required"),

  email: z.email("Enter a valid email address"),

  password: z.string().min(8, "Password must be at least 8 characters"),

  phone: z
    .string()
    .trim()
    .regex(/^9[678]\d{8}$/, "Enter a valid phone number"),

  dateOfBirth: z.coerce.date().optional(),
});

export type CreateUserInput = z.infer<typeof createUserSchema>;
