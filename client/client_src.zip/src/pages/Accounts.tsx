import { useEffect, useState } from "react";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Banknote, Landmark, Pencil, Plus, Trash2, Wallet } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import { useAccounts } from "@/hooks/useAccounts";
import type { Account, AccountType } from "@/types/account";

const accountSchema = z.object({
  name: z.string().min(1, "Account name is required"),
  type: z.enum(["cash", "bank", "wallet"]),
  balance: z.number().min(0, "Balance cannot be negative"),
});

type AccountFormData = z.infer<typeof accountSchema>;

export default function Accounts() {
  const { accounts, addAccount, updateAccount, deleteAccount } = useAccounts();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    watch,
    formState: { errors },
  } = useForm<AccountFormData>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      name: "",
      type: "cash",
      balance: 0,
    },
  });

  const selectedType = watch("type");

  useEffect(() => {
    if (editingAccount) {
      reset({
        name: editingAccount.name,
        type: editingAccount.type,
        balance: editingAccount.balance,
      });
    } else {
      reset({
        name: "",
        type: "cash",
        balance: 0,
      });
    }
  }, [editingAccount, reset]);

  const openAddDialog = () => {
    setEditingAccount(null);

    reset({
      name: "",
      type: "cash",
      balance: 0,
    });

    setDialogOpen(true);
  };

  const openEditDialog = (account: Account) => {
    setEditingAccount(account);
    setDialogOpen(true);
  };

  const handleFormSubmit = (data: AccountFormData) => {
    if (editingAccount) {
      updateAccount(editingAccount.id, {
        name: data.name,
        type: data.type,
        balance: data.balance,
      });
    } else {
      addAccount({
        name: data.name,
        type: data.type,
        balance: data.balance,
      });
    }

    setDialogOpen(false);
    setEditingAccount(null);

    reset({
      name: "",
      type: "cash",
      balance: 0,
    });
  };

  const handleDelete = () => {
    if (!deleteId) return;

    deleteAccount(deleteId);
    setDeleteId(null);
  };

  const getIcon = (accountType: AccountType) => {
    if (accountType === "cash") {
      return Banknote;
    }

    if (accountType === "bank") {
      return Landmark;
    }

    return Wallet;
  };

  const totalBalance = accounts.reduce(
    (total, account) => total + account.balance,
    0,
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Accounts</h1>

          <p className="text-muted-foreground">
            Manage your cash, bank accounts and digital wallets
          </p>
        </div>

        <Button onClick={openAddDialog}>
          <Plus />
          Add Account
        </Button>
      </div>

      {/* Total Balance */}
      <Card>
        <CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">Total Balance</p>

          <p className="mt-1 text-3xl font-bold">
            Rs. {totalBalance.toLocaleString()}
          </p>
        </CardContent>
      </Card>

      {/* Accounts */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {accounts.map((account) => {
          const Icon = getIcon(account.type);

          return (
            <Card key={account.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Icon className="size-5" />
                    </div>

                    <CardTitle>{account.name}</CardTitle>
                  </div>

                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEditDialog(account)}
                    >
                      <Pencil />
                    </Button>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                      onClick={() => setDeleteId(account.id)}
                    >
                      <Trash2 />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <p className="text-2xl font-bold">
                  Rs. {account.balance.toLocaleString()}
                </p>

                <p className="mt-1 text-sm capitalize text-muted-foreground">
                  {account.type === "wallet" ? "Digital Wallet" : account.type}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Add / Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle>
              {editingAccount ? "Edit Account" : "Add Account"}
            </DialogTitle>

            <DialogDescription>
              {editingAccount
                ? "Update your account details."
                : "Add a new account or digital wallet."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-5">
            {/* Name */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Account Name</label>

              <input
                placeholder="e.g. NIC Asia"
                {...register("name")}
                className="flex h-9 w-full rounded-md border bg-transparent px-3 py-1 text-sm shadow-xs outline-none"
              />

              {errors.name && (
                <p className="text-sm text-destructive">
                  {errors.name.message}
                </p>
              )}
            </div>

            {/* Type */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Account Type</label>

              <select
                value={selectedType}
                onChange={(e) =>
                  setValue("type", e.target.value as AccountType, {
                    shouldValidate: true,
                  })
                }
                className="flex h-9 w-full rounded-md border bg-transparent px-3 py-1 text-sm shadow-xs outline-none"
              >
                <option value="cash">Cash</option>

                <option value="bank">Bank Account</option>

                <option value="wallet">Digital Wallet</option>
              </select>

              {errors.type && (
                <p className="text-sm text-destructive">
                  {errors.type.message}
                </p>
              )}
            </div>

            {/* Balance */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Current Balance</label>

              <input
                type="number"
                min="0"
                placeholder="e.g. 15000"
                {...register("balance", {
                  valueAsNumber: true,
                })}
                className="flex h-9 w-full rounded-md border bg-transparent px-3 py-1 text-sm shadow-xs outline-none"
              />

              {errors.balance && (
                <p className="text-sm text-destructive">
                  {errors.balance.message}
                </p>
              )}
            </div>

            {/* Submit */}
            <Button type="submit" className="w-full">
              {editingAccount ? "Update Account" : "Add Account"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={deleteId !== null}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteId(null);
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete account?</AlertDialogTitle>

            <AlertDialogDescription>
              This account will be permanently deleted. This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>

          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>

            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
