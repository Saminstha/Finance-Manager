import { useEffect, useState } from "react";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Pencil, Plus, Trash2, Target } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

import { useSavings } from "@/hooks/useSavings";
import type { Saving } from "@/types/saving";

const savingSchema = z
  .object({
    name: z.string().min(1, "Goal name is required"),

    targetAmount: z.number().positive("Target amount must be greater than 0"),

    savedAmount: z.number().min(0, "Saved amount cannot be negative"),

    deadline: z.string().optional(),
  })
  .refine((data) => data.savedAmount <= data.targetAmount, {
    message: "Saved amount cannot be greater than target amount",
    path: ["savedAmount"],
  });

type SavingFormData = z.infer<typeof savingSchema>;

export default function Savings() {
  const { savings, addSaving, updateSaving, deleteSaving } = useSavings();

  const [open, setOpen] = useState(false);

  const [editingSaving, setEditingSaving] = useState<Saving | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<SavingFormData>({
    resolver: zodResolver(savingSchema),

    defaultValues: {
      name: "",
      targetAmount: 0,
      savedAmount: 0,
      deadline: "",
    },
  });

  useEffect(() => {
    if (editingSaving) {
      reset({
        name: editingSaving.name,
        targetAmount: editingSaving.targetAmount,
        savedAmount: editingSaving.savedAmount,
        deadline: editingSaving.deadline ?? "",
      });
    } else {
      reset({
        name: "",
        targetAmount: 0,
        savedAmount: 0,
        deadline: "",
      });
    }
  }, [editingSaving, reset]);

  const openAddDialog = () => {
    setEditingSaving(null);

    reset({
      name: "",
      targetAmount: 0,
      savedAmount: 0,
      deadline: "",
    });

    setOpen(true);
  };

  const openEditDialog = (saving: Saving) => {
    setEditingSaving(saving);
    setOpen(true);
  };

  const handleFormSubmit = (data: SavingFormData) => {
    const savingData = {
      name: data.name,
      targetAmount: data.targetAmount,
      savedAmount: data.savedAmount,
      deadline: data.deadline || undefined,
    };

    if (editingSaving) {
      updateSaving(editingSaving.id, savingData);
    } else {
      addSaving(savingData);
    }

    setOpen(false);
    setEditingSaving(null);

    reset({
      name: "",
      targetAmount: 0,
      savedAmount: 0,
      deadline: "",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Savings Goals</h1>

          <p className="text-muted-foreground">
            Track your progress towards your financial goals
          </p>
        </div>

        <Button onClick={openAddDialog}>
          <Plus />
          Add Goal
        </Button>
      </div>

      {/* Add / Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {editingSaving ? "Edit Savings Goal" : "Add Savings Goal"}
            </DialogTitle>

            <DialogDescription>
              Set a target and track how much you have saved.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
            {/* Goal Name */}
            <div>
              <label className="mb-2 block text-sm font-medium">
                Goal Name
              </label>

              <input
                {...register("name")}
                className="w-full rounded-md border bg-background px-3 py-2"
                placeholder="e.g. New Laptop"
              />

              {errors.name && (
                <p className="mt-1 text-sm text-destructive">
                  {errors.name.message}
                </p>
              )}
            </div>

            {/* Target Amount */}
            <div>
              <label className="mb-2 block text-sm font-medium">
                Target Amount
              </label>

              <input
                type="number"
                {...register("targetAmount", {
                  valueAsNumber: true,
                })}
                className="w-full rounded-md border bg-background px-3 py-2"
                placeholder="120000"
              />

              {errors.targetAmount && (
                <p className="mt-1 text-sm text-destructive">
                  {errors.targetAmount.message}
                </p>
              )}
            </div>

            {/* Saved Amount */}
            <div>
              <label className="mb-2 block text-sm font-medium">
                Saved Amount
              </label>

              <input
                type="number"
                {...register("savedAmount", {
                  valueAsNumber: true,
                })}
                className="w-full rounded-md border bg-background px-3 py-2"
                placeholder="45000"
              />

              {errors.savedAmount && (
                <p className="mt-1 text-sm text-destructive">
                  {errors.savedAmount.message}
                </p>
              )}
            </div>

            {/* Deadline */}
            <div>
              <label className="mb-2 block text-sm font-medium">Deadline</label>

              <input
                type="date"
                {...register("deadline")}
                className="w-full rounded-md border bg-background px-3 py-2"
              />
            </div>

            {/* Submit */}
            <Button type="submit" className="w-full">
              {editingSaving ? "Update Goal" : "Add Goal"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Savings Goals */}
      <div className="grid gap-4 md:grid-cols-2">
        {savings.map((saving) => {
          const percentage = Math.min(
            (saving.savedAmount / saving.targetAmount) * 100,
            100,
          );

          const remaining = Math.max(
            saving.targetAmount - saving.savedAmount,
            0,
          );

          return (
            <div key={saving.id} className="rounded-xl border bg-card p-5">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-muted p-3">
                    <Target />
                  </div>

                  <div>
                    <h2 className="font-semibold">{saving.name}</h2>

                    {saving.deadline && (
                      <p className="text-sm text-muted-foreground">
                        Deadline: {saving.deadline}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex gap-1">
                  {/* Edit */}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => openEditDialog(saving)}
                  >
                    <Pencil />
                  </Button>

                  {/* Delete */}
                  <AlertDialog>
                    <AlertDialogTrigger>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                      >
                        <Trash2 />
                      </Button>
                    </AlertDialogTrigger>

                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          Delete savings goal?
                        </AlertDialogTitle>

                        <AlertDialogDescription>
                          This will permanently delete "{saving.name}".
                        </AlertDialogDescription>
                      </AlertDialogHeader>

                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>

                        <AlertDialogAction
                          onClick={() => deleteSaving(saving.id)}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>

              {/* Progress */}
              <div className="mt-5 space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Rs. {saving.savedAmount.toLocaleString()}</span>

                  <span>Rs. {saving.targetAmount.toLocaleString()}</span>
                </div>

                <Progress value={percentage} />

                <div className="flex justify-between text-sm">
                  <span className="font-medium">
                    {percentage.toFixed(0)}% saved
                  </span>

                  <span className="text-muted-foreground">
                    {remaining > 0
                      ? `Rs. ${remaining.toLocaleString()} remaining`
                      : "Goal completed 🎉"}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
