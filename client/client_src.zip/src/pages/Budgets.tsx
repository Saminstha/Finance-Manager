import { useEffect, useState } from "react";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Pencil, Plus, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import { useBudgets } from "@/hooks/useBudgets";
import { useTransactions } from "@/hooks/useTransactions";

import type { Budget } from "@/types/budget";

const categories = [
  "Food",
  "Transport",
  "Shopping",
  "Bills",
  "Entertainment",
  "Other",
];

const budgetSchema = z.object({
  category: z.string().min(1, "Category is required"),
  limit: z.number().positive("Monthly limit must be greater than 0"),
});

type BudgetFormData = z.infer<typeof budgetSchema>;

export default function Budgets() {
  const { budgets, addBudget, updateBudget, deleteBudget } = useBudgets();

  const { transactions } = useTransactions();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const currentMonth = new Date().toISOString().slice(0, 7);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    watch,
    formState: { errors },
  } = useForm<BudgetFormData>({
    resolver: zodResolver(budgetSchema),
    defaultValues: {
      category: "",
      limit: 0,
    },
  });

  const selectedCategory = watch("category");

  useEffect(() => {
    if (editingBudget) {
      reset({
        category: editingBudget.category,
        limit: editingBudget.limit,
      });
    } else {
      reset({
        category: "",
        limit: 0,
      });
    }
  }, [editingBudget, reset]);

  const openAddDialog = () => {
    setEditingBudget(null);
    reset({
      category: "",
      limit: 0,
    });
    setDialogOpen(true);
  };

  const openEditDialog = (budget: Budget) => {
    setEditingBudget(budget);
    setDialogOpen(true);
  };

  const handleFormSubmit = (data: BudgetFormData) => {
    if (editingBudget) {
      updateBudget(editingBudget.id, {
        category: data.category,
        limit: data.limit,
        month: editingBudget.month,
      });
    } else {
      addBudget({
        category: data.category,
        limit: data.limit,
        month: currentMonth,
      });
    }

    setDialogOpen(false);
    setEditingBudget(null);

    reset({
      category: "",
      limit: 0,
    });
  };

  const handleDelete = () => {
    if (!deleteId) return;

    deleteBudget(deleteId);
    setDeleteId(null);
  };

  const getSpent = (budget: Budget) => {
    return transactions
      .filter(
        (transaction) =>
          transaction.type === "expense" &&
          transaction.category === budget.category &&
          transaction.date.startsWith(budget.month),
      )
      .reduce((total, transaction) => total + transaction.amount, 0);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Budgets</h1>

          <p className="text-muted-foreground">
            Set and manage your monthly spending limits
          </p>
        </div>

        <Button onClick={openAddDialog}>
          <Plus />
          Add Budget
        </Button>
      </div>

      {/* Budget Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {budgets.map((budget) => {
          const spent = getSpent(budget);
          const remaining = budget.limit - spent;

          const percentage =
            budget.limit > 0 ? (spent / budget.limit) * 100 : 0;

          const progress = Math.min(percentage, 100);

          return (
            <Card key={budget.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{budget.category}</CardTitle>

                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEditDialog(budget)}
                    >
                      <Pencil />
                    </Button>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                      onClick={() => setDeleteId(budget.id)}
                    >
                      <Trash2 />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Limit */}
                <div>
                  <p className="text-2xl font-bold">
                    Rs. {budget.limit.toLocaleString()}
                  </p>

                  <p className="text-sm text-muted-foreground">Monthly limit</p>
                </div>

                {/* Progress */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Spent: Rs. {spent.toLocaleString()}</span>

                    <span>{Math.round(percentage)}%</span>
                  </div>

                  <Progress value={progress} />
                </div>

                {/* Remaining */}
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">
                    {remaining >= 0 ? "Remaining" : "Over budget"}
                  </span>

                  <span
                    className={
                      remaining >= 0
                        ? "font-medium"
                        : "font-medium text-destructive"
                    }
                  >
                    Rs. {Math.abs(remaining).toLocaleString()}
                  </span>
                </div>

                <p className="text-xs text-muted-foreground">{budget.month}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Add / Edit Budget Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle>
              {editingBudget ? "Edit Budget" : "Add Budget"}
            </DialogTitle>

            <DialogDescription>
              {editingBudget
                ? "Update your monthly budget."
                : "Create a spending limit for a category."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-5">
            {/* Category */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>

              <select
                value={selectedCategory}
                onChange={(e) =>
                  setValue("category", e.target.value, {
                    shouldValidate: true,
                  })
                }
                className="flex h-9 w-full rounded-md border bg-transparent px-3 py-1 text-sm shadow-xs outline-none"
              >
                <option value="">Select category</option>

                {categories.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>

              {errors.category && (
                <p className="text-sm text-destructive">
                  {errors.category.message}
                </p>
              )}
            </div>

            {/* Limit */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Monthly Limit</label>

              <input
                type="number"
                min="1"
                placeholder="e.g. 10000"
                {...register("limit", {
                  valueAsNumber: true,
                })}
                className="flex h-9 w-full rounded-md border bg-transparent px-3 py-1 text-sm shadow-xs outline-none"
              />

              {errors.limit && (
                <p className="text-sm text-destructive">
                  {errors.limit.message}
                </p>
              )}
            </div>

            {/* Submit */}
            <Button type="submit" className="w-full">
              {editingBudget ? "Update Budget" : "Add Budget"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={deleteId !== null}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteId(null);
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete budget?</AlertDialogTitle>

            <AlertDialogDescription>
              This budget will be permanently deleted. This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>

          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>

            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
