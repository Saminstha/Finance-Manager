import { useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Pencil,
  Plus,
  Search,
  Trash2,
  X,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

import { TRANSACTION_CATEGORIES, ACCOUNTS } from "@/constants/finance";

import AddTransactionForm from "@/components/transactions/AddTransactionForm";
import { useTransactions } from "@/hooks/useTransactions";
import type { Transaction, TransactionType } from "@/types/transaction";

export default function Transactions() {
  const { transactions, addTransaction, updateTransaction, deleteTransaction } =
    useTransactions();

  const [open, setOpen] = useState(false);

  const [editingTransaction, setEditingTransaction] =
    useState<Transaction | null>(null);

  // Filters
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | TransactionType>("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [accountFilter, setAccountFilter] = useState("all");
  const [monthFilter, setMonthFilter] = useState("all");

  const handleAddTransaction = (data: Omit<Transaction, "id">) => {
    addTransaction(data);
    setOpen(false);
  };

  const handleEditTransaction = (data: Omit<Transaction, "id">) => {
    if (!editingTransaction) return;

    updateTransaction(editingTransaction.id, data);

    setEditingTransaction(null);
  };

  // // Get unique categories
  // const categories = useMemo(() => {
  //   return Array.from(
  //     new Set(transactions.map((transaction) => transaction.category)),
  //   );
  // }, [transactions]);

  // // Get unique accounts
  // const accounts = useMemo(() => {
  //   return Array.from(
  //     new Set(transactions.map((transaction) => transaction.account)),
  //   );
  // }, [transactions]);

  // Get unique months
  const months = useMemo(() => {
    return Array.from(
      new Set(transactions.map((transaction) => transaction.date.slice(0, 7))),
    )
      .sort()
      .reverse();
  }, [transactions]);

  // Apply filters
  const filteredTransactions = useMemo(() => {
    return transactions.filter((transaction) => {
      const matchesSearch =
        transaction.title.toLowerCase().includes(search.toLowerCase()) ||
        transaction.category.toLowerCase().includes(search.toLowerCase()) ||
        transaction.account.toLowerCase().includes(search.toLowerCase());

      const matchesType =
        typeFilter === "all" || transaction.type === typeFilter;

      const matchesCategory =
        categoryFilter === "all" || transaction.category === categoryFilter;

      const matchesAccount =
        accountFilter === "all" || transaction.account === accountFilter;

      const matchesMonth =
        monthFilter === "all" || transaction.date.startsWith(monthFilter);

      return (
        matchesSearch &&
        matchesType &&
        matchesCategory &&
        matchesAccount &&
        matchesMonth
      );
    });
  }, [
    transactions,
    search,
    typeFilter,
    categoryFilter,
    accountFilter,
    monthFilter,
  ]);

  const resetFilters = () => {
    setSearch("");
    setTypeFilter("all");
    setCategoryFilter("all");
    setAccountFilter("all");
    setMonthFilter("all");
  };

  const hasFilters =
    search !== "" ||
    typeFilter !== "all" ||
    categoryFilter !== "all" ||
    accountFilter !== "all" ||
    monthFilter !== "all";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Transactions</h1>

          <p className="text-muted-foreground">
            Manage your income and expenses
          </p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger>
            <Button>
              <Plus />
              Add Transaction
            </Button>
          </DialogTrigger>

          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add Transaction</DialogTitle>

              <DialogDescription>
                Add your income or expense details below.
              </DialogDescription>
            </DialogHeader>

            <AddTransactionForm onSubmit={handleAddTransaction} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="rounded-xl border bg-card p-4">
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-5">
          {/* Search */}
          <div className="relative lg:col-span-2">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />

            <Input
              className="pl-9"
              placeholder="Search transactions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* Type */}
          <select
            value={typeFilter}
            onChange={(e) =>
              setTypeFilter(e.target.value as "all" | TransactionType)
            }
            className="h-10 rounded-md border bg-background px-3 text-sm"
          >
            <option value="all">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>

          {/* Category */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
          >
            <option value="all">All Categories</option>

            {TRANSACTION_CATEGORIES.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>

          {/* Account */}
          <select
            value={accountFilter}
            onChange={(e) => setAccountFilter(e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
          >
            <option value="all">All Accounts</option>

            {ACCOUNTS.map((account) => (
              <option key={account} value={account}>
                {account}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          {/* Month */}
          <select
            value={monthFilter}
            onChange={(e) => setMonthFilter(e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
          >
            <option value="all">All Months</option>

            {months.map((month) => (
              <option key={month} value={month}>
                {month}
              </option>
            ))}
          </select>

          {hasFilters && (
            <Button variant="ghost" onClick={resetFilters}>
              <X />
              Reset Filters
            </Button>
          )}

          <span className="text-sm text-muted-foreground">
            Showing {filteredTransactions.length} of {transactions.length}{" "}
            transactions
          </span>
        </div>
      </div>

      {/* Transactions */}
      <div className="space-y-3">
        {filteredTransactions.length === 0 ? (
          <div className="rounded-xl border bg-card p-10 text-center">
            <p className="font-medium">No transactions found</p>

            <p className="mt-1 text-sm text-muted-foreground">
              Try changing your search or filters.
            </p>
          </div>
        ) : (
          filteredTransactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between rounded-xl border bg-card p-4"
            >
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-muted p-3">
                  {transaction.type === "income" ? (
                    <ArrowUpRight className="text-green-600" />
                  ) : (
                    <ArrowDownRight className="text-red-600" />
                  )}
                </div>

                <div>
                  <h3 className="font-medium">{transaction.title}</h3>

                  <p className="text-sm text-muted-foreground">
                    {transaction.category} • {transaction.account}
                  </p>

                  <p className="text-xs text-muted-foreground">
                    {transaction.date}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div
                  className={
                    transaction.type === "income"
                      ? "font-semibold text-green-600"
                      : "font-semibold text-red-600"
                  }
                >
                  {transaction.type === "income" ? "+" : "-"} Rs.{" "}
                  {transaction.amount.toLocaleString()}
                </div>

                {/* Edit */}
                <Dialog
                  open={editingTransaction?.id === transaction.id}
                  onOpenChange={(isOpen) => {
                    if (!isOpen) {
                      setEditingTransaction(null);
                    }
                  }}
                >
                  <DialogTrigger>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingTransaction(transaction)}
                    >
                      <Pencil />
                    </Button>
                  </DialogTrigger>

                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Edit Transaction</DialogTitle>

                      <DialogDescription>
                        Update your transaction details below.
                      </DialogDescription>
                    </DialogHeader>

                    <AddTransactionForm
                      initialData={{
                        title: transaction.title,
                        amount: transaction.amount,
                        type: transaction.type,
                        category: transaction.category,
                        account: transaction.account,
                        date: transaction.date,
                        description: transaction.description,
                      }}
                      submitLabel="Update Transaction"
                      onSubmit={handleEditTransaction}
                    />
                  </DialogContent>
                </Dialog>

                {/* Delete */}
                <AlertDialog>
                  <AlertDialogTrigger>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                    >
                      <Trash2 />
                    </Button>
                  </AlertDialogTrigger>

                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete transaction?</AlertDialogTitle>

                      <AlertDialogDescription>
                        This will permanently delete "{transaction.title}". This
                        action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>

                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>

                      <AlertDialogAction
                        onClick={() => deleteTransaction(transaction.id)}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
