export interface Budget {
  id: string;
  category: string;
  limit: number;
  month: string;
}
