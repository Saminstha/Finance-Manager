import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

import type { User } from "@/api/authApi";

interface AuthState {
  user: User | null;
  accessToken: string | null;
  isAuthenticated: boolean;
  isInitializing: boolean;
}

const initialToken = localStorage.getItem("accessToken");

const initialState: AuthState = {
  user: null,
  accessToken: initialToken,
  isAuthenticated: !!initialToken,
  isInitializing: true,
};

const authSlice = createSlice({
  name: "auth",

  initialState,

  reducers: {
    login: (
      state,
      action: PayloadAction<{
        user: User;
        token: string;
      }>,
    ) => {
      state.user = action.payload.user;
      state.accessToken = action.payload.token;
      state.isAuthenticated = true;
      state.isInitializing = false;

      localStorage.setItem("accessToken", action.payload.token);
    },

    setUser: (state, action: PayloadAction<User>) => {
      state.user = action.payload;
      state.isAuthenticated = true;
      state.isInitializing = false;
    },

    finishInitialization: (state) => {
      state.isInitializing = false;
    },

    logout: (state) => {
      state.user = null;
      state.accessToken = null;
      state.isAuthenticated = false;
      state.isInitializing = false;

      localStorage.removeItem("accessToken");
    },
  },
});

export const { login, setUser, finishInitialization, logout } =
  authSlice.actions;

export default authSlice.reducer;
