import type { Transaction } from "@/types/transaction";

export const transactions: Transaction[] = [
  {
    id: "1",
    title: "Salary",
    amount: 65000,
    type: "income",
    category: "Salary",
    account: "Bank Account",
    date: "2026-09-01",
    description: "Monthly salary",
  },
  {
    id: "2",
    title: "Groceries",
    amount: 2500,
    type: "expense",
    category: "Food",
    account: "Cash",
    date: "2026-09-02",
    description: "Monthly groceries",
  },
  {
    id: "3",
    title: "Internet Bill",
    amount: 1500,
    type: "expense",
    category: "Utilities",
    account: "eSewa",
    date: "2026-09-03",
  },
  {
    id: "4",
    title: "Freelance Work",
    amount: 10000,
    type: "income",
    category: "Freelance",
    account: "Bank Account",
    date: "2026-09-04",
  },
];
