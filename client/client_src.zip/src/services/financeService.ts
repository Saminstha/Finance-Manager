import type { Transaction } from "@/types/transaction";

export function calculateFinanceSummary(transactions: Transaction[]) {
  const income = transactions
    .filter((transaction) => transaction.type === "income")
    .reduce((total, transaction) => total + transaction.amount, 0);

  const expenses = transactions
    .filter((transaction) => transaction.type === "expense")
    .reduce((total, transaction) => total + transaction.amount, 0);

  const balance = income - expenses;

  const savings = balance;

  return {
    income,
    expenses,
    balance,
    savings,
  };
}
