import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

import type { Transaction } from "@/types/transaction";

interface TransactionState {
  transactions: Transaction[];
}

const initialState: TransactionState = {
  transactions: [
    {
      id: "1",
      title: "Salary",
      amount: 65000,
      type: "income",
      category: "Salary",
      account: "Bank Account",
      date: "2026-09-01",
      description: "Monthly salary",
    },
    {
      id: "2",
      title: "Groceries",
      amount: 2500,
      type: "expense",
      category: "Food",
      account: "Cash",
      date: "2026-09-02",
      description: "Monthly groceries",
    },
    {
      id: "3",
      title: "Internet Bill",
      amount: 1500,
      type: "expense",
      category: "Utilities",
      account: "eSewa",
      date: "2026-09-03",
    },
    {
      id: "4",
      title: "Freelance Work",
      amount: 10000,
      type: "income",
      category: "Freelance",
      account: "Bank Account",
      date: "2026-09-04",
    },
  ],
};

const transactionSlice = createSlice({
  name: "transactions",
  initialState,
  reducers: {
    addTransaction: (state, action: PayloadAction<Transaction>) => {
      state.transactions.unshift(action.payload);
    },

    updateTransaction: (state, action: PayloadAction<Transaction>) => {
      const index = state.transactions.findIndex(
        (transaction) => transaction.id === action.payload.id,
      );

      if (index !== -1) {
        state.transactions[index] = action.payload;
      }
    },

    deleteTransaction: (state, action: PayloadAction<string>) => {
      state.transactions = state.transactions.filter(
        (transaction) => transaction.id !== action.payload,
      );
    },
  },
});

export const { addTransaction, updateTransaction, deleteTransaction } =
  transactionSlice.actions;

export default transactionSlice.reducer;
