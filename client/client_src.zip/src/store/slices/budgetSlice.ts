import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

import type { Budget } from "@/types/budget";

interface BudgetState {
  budgets: Budget[];
}

const initialState: BudgetState = {
  budgets: [
    {
      id: "1",
      category: "Food",
      limit: 10000,
      month: "2026-09",
    },
    {
      id: "2",
      category: "Transport",
      limit: 5000,
      month: "2026-09",
    },
    {
      id: "3",
      category: "Shopping",
      limit: 8000,
      month: "2026-09",
    },
  ],
};

const budgetSlice = createSlice({
  name: "budgets",
  initialState,
  reducers: {
    addBudget: (state, action: PayloadAction<Omit<Budget, "id">>) => {
      const newBudget: Budget = {
        id: Date.now().toString(),
        ...action.payload,
      };

      state.budgets.unshift(newBudget);
    },

    updateBudget: (
      state,
      action: PayloadAction<{
        id: string;
        budget: Omit<Budget, "id">;
      }>,
    ) => {
      const index = state.budgets.findIndex(
        (budget) => budget.id === action.payload.id,
      );

      if (index !== -1) {
        state.budgets[index] = {
          id: action.payload.id,
          ...action.payload.budget,
        };
      }
    },

    deleteBudget: (state, action: PayloadAction<string>) => {
      state.budgets = state.budgets.filter(
        (budget) => budget.id !== action.payload,
      );
    },
  },
});

export const { addBudget, updateBudget, deleteBudget } = budgetSlice.actions;

export default budgetSlice.reducer;
