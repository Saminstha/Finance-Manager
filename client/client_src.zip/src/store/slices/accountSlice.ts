import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

import type { Account } from "@/types/account";
import type { Transaction } from "@/types/transaction";

interface AccountState {
  accounts: Account[];
}

const initialState: AccountState = {
  accounts: [
    {
      id: "1",
      name: "Cash",
      type: "cash",
      balance: 15000,
    },
    {
      id: "2",
      name: "Bank Account",
      type: "bank",
      balance: 45000,
    },
    {
      id: "3",
      name: "eSewa",
      type: "wallet",
      balance: 8000,
    },
    {
      id: "4",
      name: "Khalti",
      type: "wallet",
      balance: 5000,
    },
  ],
};

const accountSlice = createSlice({
  name: "accounts",
  initialState,
  reducers: {
    addAccount: (state, action: PayloadAction<Omit<Account, "id">>) => {
      const newAccount: Account = {
        id: Date.now().toString(),
        ...action.payload,
      };

      state.accounts.unshift(newAccount);
    },

    updateAccount: (
      state,
      action: PayloadAction<{
        id: string;
        account: Omit<Account, "id">;
      }>,
    ) => {
      const index = state.accounts.findIndex(
        (account) => account.id === action.payload.id,
      );

      if (index !== -1) {
        state.accounts[index] = {
          id: action.payload.id,
          ...action.payload.account,
        };
      }
    },

    deleteAccount: (state, action: PayloadAction<string>) => {
      state.accounts = state.accounts.filter(
        (account) => account.id !== action.payload,
      );
    },

    applyTransaction: (state, action: PayloadAction<Transaction>) => {
      const account = state.accounts.find(
        (account) => account.name === action.payload.account,
      );

      if (!account) return;

      const change =
        action.payload.type === "income"
          ? action.payload.amount
          : -action.payload.amount;

      account.balance += change;
    },

    reverseTransaction: (state, action: PayloadAction<Transaction>) => {
      const account = state.accounts.find(
        (account) => account.name === action.payload.account,
      );

      if (!account) return;

      const change =
        action.payload.type === "income"
          ? -action.payload.amount
          : action.payload.amount;

      account.balance += change;
    },
  },
});

export const {
  addAccount,
  updateAccount,
  deleteAccount,
  applyTransaction,
  reverseTransaction,
} = accountSlice.actions;

export default accountSlice.reducer;
