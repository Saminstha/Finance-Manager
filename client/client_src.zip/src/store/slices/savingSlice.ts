import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

import type { Saving } from "@/types/saving";

interface SavingState {
  savings: Saving[];
}

const initialState: SavingState = {
  savings: [
    {
      id: "1",
      name: "New Laptop",
      targetAmount: 120000,
      savedAmount: 45000,
      deadline: "2027-01-01",
    },
    {
      id: "2",
      name: "Emergency Fund",
      targetAmount: 100000,
      savedAmount: 30000,
    },
  ],
};

const savingSlice = createSlice({
  name: "savings",
  initialState,
  reducers: {
    addSaving: (state, action: PayloadAction<Omit<Saving, "id">>) => {
      const newSaving: Saving = {
        id: Date.now().toString(),
        ...action.payload,
      };

      state.savings.unshift(newSaving);
    },

    updateSaving: (
      state,
      action: PayloadAction<{
        id: string;
        saving: Omit<Saving, "id">;
      }>,
    ) => {
      const index = state.savings.findIndex(
        (saving) => saving.id === action.payload.id,
      );

      if (index !== -1) {
        state.savings[index] = {
          id: action.payload.id,
          ...action.payload.saving,
        };
      }
    },

    deleteSaving: (state, action: PayloadAction<string>) => {
      state.savings = state.savings.filter(
        (saving) => saving.id !== action.payload,
      );
    },
  },
});

export const { addSaving, updateSaving, deleteSaving } = savingSlice.actions;

export default savingSlice.reducer;
