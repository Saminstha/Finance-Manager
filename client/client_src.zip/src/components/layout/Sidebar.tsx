import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <aside className="w-64 border-r min-h-screen p-4">
      <h1 className="text-xl font-bold mb-6">Finance Manager</h1>

      <nav className="space-y-2">
        <Link to="/" className="block p-2 rounded hover:bg-muted">
          Dashboard
        </Link>

        <Link to="/transactions" className="block p-2 rounded hover:bg-muted">
          Transactions
        </Link>

        <Link to="/budgets" className="block p-2 rounded hover:bg-muted">
          Budgets
        </Link>

        <Link to="/accounts" className="block p-2 rounded hover:bg-muted">
          Accounts
        </Link>

        <Link to="/savings" className="block p-2 rounded hover:bg-muted">
          Savings
        </Link>
      </nav>
    </aside>
  );
}
