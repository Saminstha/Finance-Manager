import { useAppDispatch, useAppSelector } from "@/store/hooks";

import {
  addAccount,
  updateAccount,
  deleteAccount,
} from "@/store/slices/accountSlice";

import type { Account } from "@/types/account";

export function useAccounts() {
  const dispatch = useAppDispatch();

  const accounts = useAppSelector((state) => state.accounts.accounts);

  const handleAddAccount = (account: Omit<Account, "id">) => {
    dispatch(addAccount(account));
  };

  const handleUpdateAccount = (id: string, account: Omit<Account, "id">) => {
    dispatch(
      updateAccount({
        id,
        account,
      }),
    );
  };

  const handleDeleteAccount = (id: string) => {
    dispatch(deleteAccount(id));
  };

  return {
    accounts,
    addAccount: handleAddAccount,
    updateAccount: handleUpdateAccount,
    deleteAccount: handleDeleteAccount,
  };
}
