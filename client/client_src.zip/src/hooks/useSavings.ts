import { useAppDispatch, useAppSelector } from "@/store/hooks";

import {
  addSaving,
  updateSaving,
  deleteSaving,
} from "@/store/slices/savingSlice";

import type { Saving } from "@/types/saving";

export function useSavings() {
  const dispatch = useAppDispatch();

  const savings = useAppSelector((state) => state.savings.savings);

  const handleAddSaving = (saving: Omit<Saving, "id">) => {
    dispatch(addSaving(saving));
  };

  const handleUpdateSaving = (id: string, saving: Omit<Saving, "id">) => {
    dispatch(
      updateSaving({
        id,
        saving,
      }),
    );
  };

  const handleDeleteSaving = (id: string) => {
    dispatch(deleteSaving(id));
  };

  return {
    savings,
    addSaving: handleAddSaving,
    updateSaving: handleUpdateSaving,
    deleteSaving: handleDeleteSaving,
  };
}
