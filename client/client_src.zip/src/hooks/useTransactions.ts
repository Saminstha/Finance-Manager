import { useAppDispatch, useAppSelector } from "@/store/hooks";

import {
  addTransaction,
  updateTransaction,
  deleteTransaction,
} from "@/store/slices/transactionSlice";

import {
  applyTransaction,
  reverseTransaction,
} from "@/store/slices/accountSlice";

import type { Transaction } from "@/types/transaction";

export function useTransactions() {
  const dispatch = useAppDispatch();

  const transactions = useAppSelector(
    (state) => state.transactions.transactions,
  );

  const handleAddTransaction = (transaction: Omit<Transaction, "id">) => {
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      ...transaction,
    };

    dispatch(addTransaction(newTransaction));
    dispatch(applyTransaction(newTransaction));
  };

  const handleUpdateTransaction = (
    id: string,
    transaction: Omit<Transaction, "id">,
  ) => {
    const oldTransaction = transactions.find((item) => item.id === id);

    if (!oldTransaction) return;

    const updatedTransaction: Transaction = {
      id,
      ...transaction,
    };

    dispatch(reverseTransaction(oldTransaction));
    dispatch(updateTransaction(updatedTransaction));
    dispatch(applyTransaction(updatedTransaction));
  };

  const handleDeleteTransaction = (id: string) => {
    const transaction = transactions.find((item) => item.id === id);

    if (!transaction) return;

    dispatch(reverseTransaction(transaction));
    dispatch(deleteTransaction(id));
  };

  return {
    transactions,
    addTransaction: handleAddTransaction,
    updateTransaction: handleUpdateTransaction,
    deleteTransaction: handleDeleteTransaction,
  };
}
