import { useAppDispatch, useAppSelector } from "@/store/hooks";

import {
  addBudget,
  updateBudget,
  deleteBudget,
} from "@/store/slices/budgetSlice";

import type { Budget } from "@/types/budget";

export function useBudgets() {
  const dispatch = useAppDispatch();

  const budgets = useAppSelector((state) => state.budgets.budgets);

  const handleAddBudget = (budget: Omit<Budget, "id">) => {
    dispatch(addBudget(budget));
  };

  const handleUpdateBudget = (id: string, budget: Omit<Budget, "id">) => {
    dispatch(
      updateBudget({
        id,
        budget,
      }),
    );
  };

  const handleDeleteBudget = (id: string) => {
    dispatch(deleteBudget(id));
  };

  return {
    budgets,
    addBudget: handleAddBudget,
    updateBudget: handleUpdateBudget,
    deleteBudget: handleDeleteBudget,
  };
}
